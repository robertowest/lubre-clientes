from .comunes import *
from .diccionario import *

from .domicilio import *
from .pais import *
from .ciudad import *
from .localidad import *

from .comunicacion import *