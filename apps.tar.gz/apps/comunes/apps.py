from django.apps import AppConfig


class ComunesConfig(AppConfig):
    name = 'comunes'
