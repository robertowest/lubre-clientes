from .comunicacion import *
from .diccionario import *
from .domicilio import *
