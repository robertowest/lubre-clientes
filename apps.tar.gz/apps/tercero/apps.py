from django.apps import AppConfig


class TerceroConfig(AppConfig):
    name = 'empresa'
