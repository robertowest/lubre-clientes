from django.shortcuts import render

# Create your views here.
from .models import PruebaFilter
from apps.comunes.models import Localidad

def index(request):
    f = PruebaFilter(request.GET, queryset=Localidad.objects.all())
    return render(request, 'listado.html', {'filter': f})
    # return render(request, 'listado.html', {})


# from django.views.generic import ListView
#
# class MyList(ListView):
#     model = Localidad
#     template_name = 'listado2.html'

from django_filters.views import FilterView
from .filters import MyFilter
# from apps.comunes.models import Localidad
#
class MyList(FilterView):
    model = Localidad
    template_name = 'listado2.html'
    filterset_class = MyFilter
#
#     def get_queryset(self):
#         return Localidad.objects.order_by('nombre')
