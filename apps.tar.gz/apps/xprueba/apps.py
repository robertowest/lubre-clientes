from django.apps import AppConfig


class XpruebaConfig(AppConfig):
    name = 'xprueba'
