from django.urls import path

from . import views

app_name = 'xprueba'

urlpatterns = [
    # listado filtrado mediante class-based
    path('', views.index),
    path('vista/', views.MyList.as_view(), name='MyList'),
]